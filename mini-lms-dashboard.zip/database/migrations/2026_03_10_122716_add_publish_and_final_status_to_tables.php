<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->boolean('is_published')->default(false)->after('price');
        });

        Schema::table('lessons', function (Blueprint $table) {
            $table->boolean('is_published')->default(false)->after('video_url');
        });

        Schema::table('quizzes', function (Blueprint $table) {
            $table->boolean('is_published')->default(false)->after('pass_mark');
            $table->boolean('is_final_exam')->default(false)->after('is_published');
        });
    }

    public function down(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->dropColumn('is_published');
        });
        Schema::table('lessons', function (Blueprint $table) {
            $table->dropColumn('is_published');
        });
        Schema::table('quizzes', function (Blueprint $table) {
            $table->dropColumn(['is_published', 'is_final_exam']);
        });
    }
};