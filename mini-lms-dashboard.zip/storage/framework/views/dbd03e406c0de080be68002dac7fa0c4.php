<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split(\App\Livewire\InstructorProfileModal::class);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3525530760-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH G:\MyProjects\MiniLMS\mini-lms-dashboard\storage\framework\views/e3b5fd8f54a3e0f0a1b89ae5450a52e9.blade.php ENDPATH**/ ?>